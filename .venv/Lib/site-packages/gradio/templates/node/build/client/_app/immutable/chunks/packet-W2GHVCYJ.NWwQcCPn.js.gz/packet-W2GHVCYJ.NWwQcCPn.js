import { P, a } from "./mermaid-parser.core.D5SmifyT.js";
export {
  P as PacketModule,
  a as createPacketServices
};
