import { A, e } from "./mermaid-parser.core.D5SmifyT.js";
export {
  A as ArchitectureModule,
  e as createArchitectureServices
};
