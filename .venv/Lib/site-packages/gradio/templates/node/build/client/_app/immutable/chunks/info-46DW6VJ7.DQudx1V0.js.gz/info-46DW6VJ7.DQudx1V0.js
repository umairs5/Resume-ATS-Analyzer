import { I, c } from "./mermaid-parser.core.D5SmifyT.js";
export {
  I as InfoModule,
  c as createInfoServices
};
