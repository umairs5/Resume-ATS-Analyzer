import { X, _ } from "../chunks/2.CLHmtpxK.js";
export {
  X as component,
  _ as universal
};
